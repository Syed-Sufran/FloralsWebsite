import '../../src/index.css';

// Variables & Elements
const overlay = document.getElementById('detail-overlay');
const closeBtn = document.getElementById('close-overlay');
const carouselTrack = document.getElementById('carousel-track');
const dots = document.querySelectorAll('.carousel-dot');
const video = document.getElementById('carousel-video');
const muteBtn = document.getElementById('video-mute-btn');
const muteIcon = document.getElementById('mute-icon');
const muteText = document.getElementById('mute-text');

// State
let currentProduct = null;
let savedScrollY = 0;

// Dynamic video frame extraction to avoid AI-generated images
function extractVideoFrame(videoSrc, callback) {
  const v = document.createElement('video');
  v.src = videoSrc;
  v.muted = true;
  v.playsInline = true;
  v.preload = 'auto';

  // Seek slightly into the video to avoid any initial black frame
  v.addEventListener('loadeddata', () => {
    v.currentTime = 0.5;
  });

  v.addEventListener('seeked', () => {
    const canvas = document.createElement('canvas');
    canvas.width = v.videoWidth || 640;
    canvas.height = v.videoHeight || 360;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(v, 0, 0, canvas.width, canvas.height);

    try {
      const dataUrl = canvas.toDataURL('image/jpeg');
      callback(dataUrl);
    } catch (e) {
      console.error('Canvas frame extraction failed:', e);
      // Fail gracefully: fallback to a real photo from the site
      callback('/images/LightUpButterFly.webp');
    }
  });

  v.addEventListener('error', (e) => {
    console.error('Error loading video for frame extraction:', e);
    callback('/images/LightUpButterFly.webp');
  });
}

// Open Full-Screen Overlay
function openOverlay(productIndex) {
  currentProduct = productIndex;
  
  // Save current scroll position
  savedScrollY = window.scrollY;

  // Configure CTAs based on product selection if needed (both reuse the same photo for this test)
  const ctaOrder = document.getElementById('cta-order');
  const ctaSimilar = document.getElementById('cta-similar');
  const prodName = productIndex === 0 ? "Blush Rose Bouquet" : "Butterfly Shimmer Bouquet";
  
  if (ctaOrder) {
    ctaOrder.href = `https://wa.me/9986759958?text=Hello Zoya's Florals! I'd like to order the exact design of the ${encodeURIComponent(prodName)}.`;
  }
  if (ctaSimilar) {
    ctaSimilar.href = `https://wa.me/9986759958?text=Hello Zoya's Florals! I'd like to request something similar to the ${encodeURIComponent(prodName)}.`;
  }

  // Display overlay
  overlay.classList.remove('hidden');
  // Trigger animation next frame
  requestAnimationFrame(() => {
    overlay.classList.remove('opacity-0');
    overlay.classList.add('opacity-100');
  });

  // Prevent background scrolling while in overlay
  document.body.style.overflow = 'hidden';
  document.body.style.height = '100vh';

  // Reset scroll of the carousel track to slide 0
  if (carouselTrack) {
    carouselTrack.scrollLeft = 0;
  }

  // Manage video autoplay
  if (video) {
    video.muted = true;
    updateMuteUI();
  }
}

// Expose openOverlay globally if needed
window.openOverlay = openOverlay;

// Initialize placeholders and card listeners
function init() {
  const videoPath = '/images/pink_white_bouquet.mp4';
  
  extractVideoFrame(videoPath, (frameDataUrl) => {
    // Populate gallery images
    const prodImg0 = document.getElementById('prod-img-0');
    const prodImg1 = document.getElementById('prod-img-1');
    if (prodImg0) prodImg0.src = frameDataUrl;
    if (prodImg1) prodImg1.src = frameDataUrl;

    // Populate carousel static slides
    const carouselImg1 = document.getElementById('carousel-img-1');
    const carouselImg3 = document.getElementById('carousel-img-3');
    if (carouselImg1) carouselImg1.src = frameDataUrl;
    if (carouselImg3) carouselImg3.src = frameDataUrl;
  });

  // Wire up programmatic card clicks
  const card0 = document.getElementById('prod-card-0');
  const card1 = document.getElementById('prod-card-1');
  if (card0) card0.addEventListener('click', () => openOverlay(0));
  if (card1) card1.addEventListener('click', () => openOverlay(1));
}

// Robust timing: execute right away if DOM is already parsed
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Close Full-Screen Overlay
function closeOverlay() {
  overlay.classList.remove('opacity-100');
  overlay.classList.add('opacity-0');

  // Wait for fade transition
  setTimeout(() => {
    overlay.classList.add('hidden');
    
    // Stop video
    if (video) {
      video.pause();
    }

    // Restore background scrolling
    document.body.style.overflow = '';
    document.body.style.height = '';

    // Restore original grid scroll position
    window.scrollTo(0, savedScrollY);
  }, 300);
}

if (closeBtn) {
  closeBtn.addEventListener('click', closeOverlay);
}

// Carousel Scroll Tracking for Dot Indicators and Video Playback
if (carouselTrack) {
  carouselTrack.addEventListener('scroll', () => {
    const width = carouselTrack.clientWidth;
    const scrollLeft = carouselTrack.scrollLeft;
    const activeIndex = Math.round(scrollLeft / width);

    // Update Dots
    dots.forEach((dot, idx) => {
      if (idx === activeIndex) {
        dot.classList.remove('text-[#F2EAE4]/30');
        dot.classList.add('text-[#F2EAE4]');
      } else {
        dot.classList.remove('text-[#F2EAE4]');
        dot.classList.add('text-[#F2EAE4]/30');
      }
    });

    // Play/Pause Video based on visibility (Slide 1 is the video)
    if (video) {
      if (activeIndex === 1) {
        video.play().catch(err => console.log('Autoplay blocked:', err));
      } else {
        video.pause();
      }
    }
  });
}

// Mute/Unmute Logic
function updateMuteUI() {
  if (video.muted) {
    muteIcon.textContent = '🔇';
    muteText.textContent = 'Muted';
  } else {
    muteIcon.textContent = '🔊';
    muteText.textContent = 'Unmuted';
  }
}

if (muteBtn && video) {
  muteBtn.addEventListener('click', (e) => {
    e.stopPropagation(); // Avoid triggering carousel swipes/taps
    video.muted = !video.muted;
    updateMuteUI();
    
    // Explicit play if tapped to unmute
    if (!video.muted && video.paused) {
      video.play().catch(err => console.log(err));
    }
  });
}
