import { defineConfig } from 'vite'

export default defineConfig({
  server: {
    port: 5173
  },
  build: {
    rollupOptions: {
      input: {
        main: 'index.html',
        butterfly: 'collections/butterfly/index.html',
        themed: 'collections/themed/index.html',
        chocolate: 'collections/chocolate-bouquet/index.html',
        curated: 'collections/curated-gifts/index.html'
      }
    }
  }
})
